from .module import hello_world

__version__ = '0.1.0'
__all__ = ['hello_world']
